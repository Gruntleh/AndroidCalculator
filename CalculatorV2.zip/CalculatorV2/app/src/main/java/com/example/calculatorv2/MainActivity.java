package com.example.calculatorv2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get Output Windows
        // New number
        TextView txtOutput = findViewById(R.id.txtOutput);
        txtOutput.setText("0");
        // Total number
        TextView txtTotal = findViewById(R.id.txtTotal);
        txtTotal.setText("0");
        // Get Calculator class
        Calculator newCalc = new Calculator();
        // Subtract Button
        Button btnSubtract = findViewById(R.id.btnSubtract);
        // Multiply Button
        Button btnMultiply = findViewById(R.id.btnMultiply);
        // Divide Button
        Button btnDivide = findViewById(R.id.btnDivide);
        // Plus button
        Button btnPlus = findViewById(R.id.btnPlus);
        // On button click
        btnPlus.setOnClickListener(view -> {
            btnPlus.setText(""); // Remove Button text
            btnSubtract.setText("-"); // Ensure Text
            btnMultiply.setText("*"); // Ensure Text
            btnDivide.setText("/"); // Ensure Text
            newCalc.setBuffer(txtOutput.getText().toString()); // Send input to calculator
            newCalc.setTotal(txtTotal.getText().toString()); // Send current total to calculator
            newCalc.checkOperators();
            newCalc.addPressed();
            txtTotal.setText(newCalc.getTotal());
            txtOutput.setText("");
        });

        // Subtract button press
        btnSubtract.setOnClickListener(view -> {
            btnPlus.setText("+");
            btnSubtract.setText("");
            btnMultiply.setText("*");
            btnDivide.setText("/");
            newCalc.setBuffer(txtOutput.getText().toString()); // Send input to calculator
            newCalc.setTotal(txtTotal.getText().toString());
            newCalc.checkOperators();
            newCalc.subPressed();
            txtTotal.setText(newCalc.getTotal());
            txtOutput.setText("");
        });

        // Multiply button press
        btnMultiply.setOnClickListener(view -> {
            btnPlus.setText("+");
            btnSubtract.setText("-");
            btnMultiply.setText("");
            btnDivide.setText("/");
            newCalc.setBuffer(txtOutput.getText().toString()); // Send input to calculator
            newCalc.setTotal(txtTotal.getText().toString());
            newCalc.checkOperators();
            newCalc.mplyPressed();
            txtTotal.setText(newCalc.getTotal());
            txtOutput.setText("");
        });

        // Divide button press
        btnDivide.setOnClickListener(view -> {
            btnPlus.setText("+");
            btnSubtract.setText("-");
            btnMultiply.setText("*");
            btnDivide.setText("");
            newCalc.setBuffer(txtOutput.getText().toString()); // Send input to calculator
            newCalc.setTotal(txtTotal.getText().toString());
            newCalc.checkOperators();
            newCalc.divPressed();
            txtTotal.setText(newCalc.getTotal());
            txtOutput.setText("");
        });

        // Clear Button
        Button btnClear = findViewById(R.id.btnClear);
        // When user clicks on button
        btnClear.setOnClickListener(view -> {
            // Reset All text
            btnPlus.setText("+");
            btnSubtract.setText("-");
            btnMultiply.setText("*");
            btnDivide.setText("/");
            txtTotal.setText("0");
            txtOutput.setText("0");
            newCalc.clearData();
        });

        // Button One
        Button btnOne = findViewById(R.id.btnOne);
        // When user clicks on button
        btnOne.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnOne.getText().toString())));

        // Button Two
        Button btnTwo = findViewById(R.id.btnTwo);
        // When user clicks on button
        btnTwo.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnTwo.getText().toString())));

        // Button Three
        Button btnThree = findViewById(R.id.btnThree);
        // When user clicks on button
        btnThree.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnThree.getText().toString())));

        // Button Four
        Button btnFour = findViewById(R.id.btnFour);
        // When user clicks on button
        btnFour.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnFour.getText().toString())));

        // Button Five
        Button btnFive = findViewById(R.id.btnFive);
        // When user clicks on button
        btnFive.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnFive.getText().toString())));

        // Button Six
        Button btnSix = findViewById(R.id.btnSix);
        // When user clicks on button
        btnSix.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnSix.getText().toString())));

        // Button Seven
        Button btnSeven = findViewById(R.id.btnSeven);
        // When user clicks on button
        btnSeven.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnSeven.getText().toString())));

        // Button eight
        Button btnEight = findViewById(R.id.btnEight);
        // When user clicks on button
        btnEight.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnEight.getText().toString())));

        // Button Nine
        Button btnNine = findViewById(R.id.btnNine);
        // When user clicks on button
        btnNine.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnNine.getText().toString())));

        // Button Zero
        Button btnZero = findViewById(R.id.btnZero);
        // When user clicks on button
        btnZero.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnZero.getText().toString())));

        // Button Period
        Button btnPeriod = findViewById(R.id.btnPeriod);
        // When user clicks on button
        btnPeriod.setOnClickListener(view -> txtOutput.setText(newCalc.newNum(btnPeriod.getText().toString())));
    }
}