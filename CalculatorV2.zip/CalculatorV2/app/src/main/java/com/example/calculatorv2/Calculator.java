package com.example.calculatorv2;

import android.widget.TextView;

public class Calculator {
    double userTotal, userNum;
    String userString, totalString;
    public boolean btnAdd, btnSub, btnMply, btnDiv;

    public Calculator()
    {
        userString = "";
        totalString = "";
        userNum = 0;
        userTotal = 0;
        btnAdd = false;
        btnSub = false;
        btnMply = false;
        btnDiv = false;
    }

    public void setBuffer(String buff)
    {
        userString = buff;
        userNum = Double.parseDouble(userString);
    }

    public void setTotal(String currentTotal)
    {
        totalString = currentTotal;
        userTotal = Double.parseDouble(totalString);
    }

    // Setter for addPressed
    public void addPressed()
    {
        btnAdd = true;
    }

    // Setting for subPressed
    public void subPressed(){ btnSub = true; }

    // Setting for mplyPressed
    public void mplyPressed(){ btnMply = true; }

    public void  divPressed(){ btnDiv = true; }

    // Getter for user total
    public String getTotal()
    {
        if (userTotal == 0)
        {
            totalString = Double.toString(userNum);
        }
        userString = "";
        return totalString;
    }

    public String newNum(String num)
    {
        userString = userString + num;
        return userString;
    }

    public void clearData()
    {
        userTotal = 0;
        userNum = 0;
        userString = "";
        totalString = "";
        btnAdd = false;
        btnSub = false;
        btnMply = false;
        btnDiv = false;
    }

    public void checkOperators()
    {
        if (btnAdd)
        {
            userTotal += userNum;
            totalString = Double.toString(userTotal);
            btnAdd = false;
        } else if (btnSub)
        {
            userTotal -= userNum;
            totalString = Double.toString(userTotal);
            btnSub = false;
        }
        else if (btnMply)
        {
            userTotal *= userNum;
            totalString = Double.toString(userTotal);
            btnMply = false;
        } else if (btnDiv)
        {
            userTotal /= userNum;
            totalString = Double.toString(userTotal);
            btnDiv = false;
        }
    }
}
